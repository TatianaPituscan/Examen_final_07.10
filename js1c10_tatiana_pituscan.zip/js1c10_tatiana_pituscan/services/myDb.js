var fs = require('fs');

function getCollectionPath(collectionName) {
    return './database/' + collectionName + '.json';
} 

function _getCollection(collectionName) {
    var collectionPath = getCollectionPath(collectionName);
    return new Promise(function(resolve, reject) {
        fs.readFile(collectionPath, function(err, data) {
            if(err) {
                reject(err);
            } else {
                var collection = JSON.parse(data.toString());
                resolve(collection);
            }
        }); 
    });
}

function _getItemCollection(collectionName, collectionItemId) {
     return Promise.resolve()
        .then(function() {
            return _getCollection(collectionName);
        })
        .then(function(collection) {
            var collectionItem = collection.find(function(collectionItem) {
                return collectionItem.id == collectionItemId
            });
            return Promise.resolve(collectionItem);
        });
}

function _saveCollection(collectionName, collection) {
    var collectionPath = getCollectionPath(collectionName);
    return new Promise(function(resolve, reject) {
        
        fs.writeFile(collectionPath, JSON.stringify(collection), function(err) {
            if(err) {
                reject(error);
            } else {
                resolve();
            }
        });
    });
}

function _insertIntemCollection(collectionName, collectionItem) {
    return Promise.resolve()
        .then(function() {
            return _getCollection(collectionName);
        })
        .then(function(collection) {
            console.log('collection: ', JSON.stringify(collection));
            collection.push(collectionItem);
            return Promise.resolve(collection);
        })
        .then(function(collection) {
            console.log('new collection: ', JSON.stringify(collection));
            return _saveCollection(collectionName, collection);
        });
}

function _updateItemCollection(collectionName, collectionItem) {
    return Promise.resolve()
        .then(function() {
            return _getCollection(collectionName);
        })
        .then(function(collection) {
            for(var i = 0; i<collection.length; i++) {
                if(collection[i].id == collectionItem.id) {
                   collection[i] = collectionItem;
                    break;
                }
            }
            return Promise.resolve(collection);
        })
        .then(function(collection) {
            return _saveCollection(collectionName, collection);
        });A
}


module.exports = {
    getCollection: _getCollection,
    getItemCollection: _getItemCollection,
    insertIntemCollection: _insertIntemCollection,
    updateItemCollection: _updateItemCollection
};
















