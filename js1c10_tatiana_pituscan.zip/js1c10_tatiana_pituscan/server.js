// Add dependencies
var express = require('express');
var bodyParser = require('body-parser');

// Instantiate express app
var app = express();

// Set middlewares
app.use(express.static('client'));
app.use(bodyParser.json());

// TODO: Implement routes

var myDb = require('./services/myDb');

app.get('/api/products', function(req, res) {
    myDb.getCollection('products')
    .then(function(results) {
        res.status(200).send(results);
    })
    .catch(function(error) {
        res.status(400).send(error);
    });
});


app.post('/api/contacts', function(req, res) {
    var contact = req.body;
    myDb.insertIntemCollection('contacts', contact)
        .then(function(contact) {
            res.status(200).send(contact);
        })
        .catch(function(error) {
            res.status(400).send(error);
        });
});

var APP_HOST = 'localhost', APP_PORT = 3000;

/*console.log(process.env.NODE_ENV);
switch(process.env.NODE_ENV) {
    case 'dev': 
        APP_HOST = 'localhost';
        APP_PORT = 3000;
        break;
    case 'prod':
        APP_HOST = 'localhost';
        APP_PORT = 8080;
        break;
    default:
        //throw new Error('The environment is not good!!!');
}*/

// Start server
app.listen(APP_PORT, APP_HOST, function() {
    console.log('Server started on http://' + APP_HOST + ':' + APP_PORT);
});

















