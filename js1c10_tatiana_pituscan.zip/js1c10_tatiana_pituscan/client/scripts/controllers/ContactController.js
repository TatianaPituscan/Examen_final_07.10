angular.module('js1c10').controller('ContactController', ['$scope', '$location', 'dataService', function($scope, $location, dataService) {
        
    /*
        {
            email:'',
            title:'',
            msg:''
        }
    */    

    $scope.contact = {
        email:'',
        title:'',
        msg:''
    }


    $scope.addContact = function(contact){
        dataService._addContact(contact).then(function(response){
            alert('Added to DB!');
        })
    }    
}]);






