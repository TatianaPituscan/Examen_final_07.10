angular.module('js1c10').controller('ProductsController', ['$scope', '$location', 'dataService', function($scope, $location, dataService) {
        
    /*
        {
            title:'',
            desc:'',
            quantity:'',
            price:'',
            image:''
        }
    */    
    
    $scope.query    = '';
    $scope.products = [];

    dataService._getProducts().then(function(response){
        $scope.products = response.data;
    })
        
}]);


