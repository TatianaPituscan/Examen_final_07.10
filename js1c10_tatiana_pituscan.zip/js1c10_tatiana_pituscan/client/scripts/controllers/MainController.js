angular.module('js1c10').controller('MainController', ['$scope', '$location', 'dataService', function($scope, $location, dataService) {

    $scope.menuClass = function(page) {
        var current = $location.path().substring(1);
        return page === current ? "active" : "";
    }; 
}]);





