angular.module('js1c10').controller('HomeController', ['$scope', '$location', 'dataService', function($scope, $location, dataService) {
        
        
        
}]);









