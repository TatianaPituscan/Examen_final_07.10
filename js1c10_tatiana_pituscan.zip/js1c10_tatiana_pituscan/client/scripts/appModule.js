angular.module('js1c10', ['ngRoute']);

