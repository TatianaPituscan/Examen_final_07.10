angular.module('js1c10')
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider
            .when('/home', {
                templateUrl: 'templates/home.html',
                controller: 'HomeController'
            })
            .when('/products', {
                templateUrl: 'templates/products.html',
                controller: 'ProductsController'
            })
            .when('/contact', {
                templateUrl: 'templates/contact.html',
                controller: 'ContactController'
            })
            .otherwise({ redirectTo: '/home' });
    }]);