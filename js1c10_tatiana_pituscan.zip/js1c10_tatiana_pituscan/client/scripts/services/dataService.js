angular.module('js1c10')
    .factory('dataService', ['$http', function($http) {
        
        var prefix = '/api';
        
        function _addContact(data) {
            return $http({
                method: 'POST',
                url: prefix+'/contacts',
                data: data
            });
        }
        
        function _getProducts() {
            return $http({
                method: 'GET',
                url: prefix+'/products'
            });
        }
        
        return {
            _getProducts: _getProducts,
            _addContact: _addContact,
        };
    }]);







